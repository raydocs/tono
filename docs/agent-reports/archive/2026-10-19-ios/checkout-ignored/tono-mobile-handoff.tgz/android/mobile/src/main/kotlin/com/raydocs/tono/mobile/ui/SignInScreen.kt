package com.raydocs.tono.mobile.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.autofill.ContentType
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentType
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.raydocs.tono.mobile.R
import com.raydocs.tono.mobile.engine.LoginView

/**
 * Email → code, the same passwordless flow as the desktop app. The code arrives on the user's own
 * email; the app never sees anything but what the user types.
 */
@Composable
fun SignInScreen(login: LoginView, onSend: (String) -> Unit, onVerify: (String) -> Unit, onChangeEmail: () -> Unit) {
    var email by rememberSaveable { mutableStateOf(login.email) }
    var code by rememberSaveable { mutableStateOf("") }
    val codeStep = login.challengeId != null
    Box(Modifier.fillMaxSize().background(TonoColors.Night)) {
        SeaScene(SkyState.NIGHT, Modifier.fillMaxSize(), horizon = 0.36f)
        Column(Modifier.fillMaxSize().imePadding()) {
            Column(Modifier.statusBarsPadding().padding(horizontal = 28.dp, vertical = 28.dp)) {
                Image(painterResource(R.drawable.tono_mark), contentDescription = null, modifier = Modifier.size(44.dp))
                Spacer(Modifier.height(18.dp))
                Text(stringResource(R.string.signin_title), style = MaterialTheme.typography.headlineMedium, color = TonoColors.TextPrimary, modifier = Modifier.semantics { heading() })
                Spacer(Modifier.height(6.dp))
                Text(stringResource(R.string.signin_intro), style = MaterialTheme.typography.bodyLarge, color = TonoColors.TextSecondary)
            }
            Spacer(Modifier.weight(1f))
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
                    .background(Brush.verticalGradient(listOf(TonoColors.Smoke.copy(alpha = 0.92f), TonoColors.NightDeep)))
                    .border(1.dp, TonoColors.Hairline, RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
                    .navigationBarsPadding()
                    .padding(horizontal = 22.dp, vertical = 22.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                AnimatedContent(codeStep, transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(220)) }, label = "step") { step ->
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        if (!step) {
                            OutlinedTextField(
                                value = email,
                                onValueChange = { email = it.take(254) },
                                label = { Text(stringResource(R.string.signin_email)) },
                                singleLine = true,
                                enabled = !login.busy,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Send, autoCorrectEnabled = false),
                                keyboardActions = KeyboardActions(onSend = { if (!login.busy) onSend(email) }),
                                colors = fieldColors(),
                                modifier = Modifier.fillMaxWidth().semantics { contentType = ContentType.EmailAddress },
                            )
                            PrimaryButton(stringResource(if (login.busy) R.string.signin_sending else R.string.signin_send), { onSend(email) }, enabled = !login.busy && email.isNotBlank())
                        } else {
                            Text(stringResource(R.string.signin_code_sent, login.email), style = MaterialTheme.typography.bodyMedium, color = TonoColors.TextSecondary)
                            OutlinedTextField(
                                value = code,
                                onValueChange = { v -> code = v.filter(Char::isDigit).take(6); if (code.length == 6 && !login.busy) onVerify(code) },
                                label = { Text(stringResource(R.string.signin_code)) },
                                singleLine = true,
                                enabled = !login.busy,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = { if (!login.busy) onVerify(code) }),
                                colors = fieldColors(),
                                textStyle = MaterialTheme.typography.headlineSmall,
                                modifier = Modifier.fillMaxWidth().semantics { contentType = ContentType.SmsOtpCode },
                            )
                            PrimaryButton(stringResource(if (login.busy) R.string.signin_verifying else R.string.signin_verify), { onVerify(code) }, enabled = !login.busy && code.length == 6)
                            TextButton(onClick = { code = ""; onChangeEmail() }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                                Text(stringResource(R.string.signin_change), color = TonoColors.TextSecondary)
                            }
                        }
                    }
                }
                login.errorCode?.let {
                    Text(signInError(it), style = MaterialTheme.typography.bodyMedium, color = TonoColors.Error, modifier = Modifier.semantics { liveRegion = LiveRegionMode.Assertive })
                }
                Text(stringResource(R.string.signin_privacy), style = MaterialTheme.typography.labelSmall, color = TonoColors.TextTertiary)
            }
        }
    }
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = TonoColors.Accent,
    unfocusedBorderColor = TonoColors.Hairline,
    focusedLabelColor = TonoColors.Accent,
    cursorColor = TonoColors.Accent,
    focusedContainerColor = TonoColors.NightDeep.copy(alpha = 0.4f),
    unfocusedContainerColor = TonoColors.NightDeep.copy(alpha = 0.4f),
)
